define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class globals {
    }
    globals.apiKey = "AIzaSyCk3O1iIw4aTsLzORDBoCB19qGEiItcm5c";
    globals.mapsUrl = "https://maps.googleapis.com/maps/api/js?";
    globals.addressURL = "https://maps.googleapis.com/maps/api/geocode/json?";
    globals.directionURL = "https://maps.googleapis.com/maps/api/directions/json?origin=Disneyland&destination=Universal+Studios+Hollywood";
    globals.flightsFileUrl = "flights.json";
    exports.globals = globals;
});
