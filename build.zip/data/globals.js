define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var globals = /** @class */ (function () {
        function globals() {
        }
        // static apiKey = "AIzaSyCk3O1iIw4aTsLzORDBoCB19qGEiItcm5c";
        globals.apiKey = "AIzaSyD-qZujdHh9qZPhq5YyknV-lwiijDm2jWc";
        globals.mapsUrl = "https://maps.googleapis.com/maps/api/js?";
        globals.addressURL = "https://maps.googleapis.com/maps/api/geocode/json?";
        return globals;
    }());
    exports.globals = globals;
});
//# sourceMappingURL=globals.js.map