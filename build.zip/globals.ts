export class globals {
    // static apiKey = "AIzaSyCk3O1iIw4aTsLzORDBoCB19qGEiItcm5c";
    static apiKey = "AIzaSyD-qZujdHh9qZPhq5YyknV-lwiijDm2jWc";
    static mapsUrl = "https://maps.googleapis.com/maps/api/js?";
    static addressURL = "https://maps.googleapis.com/maps/api/geocode/json?";
} 