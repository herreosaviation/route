declare module 'googlemaps';

interface String {
    toHHMM(): String
    toKMMM(): String
}

interface Number {
    toHHMM(): String
    toKMMM(): String
}